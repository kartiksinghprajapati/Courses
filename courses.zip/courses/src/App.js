import React from 'react';
import { Button, Jumbotron, Container, Row, Col} from 'reactstrap';

import { ToastContainer, toast } from 'react-toastify';
import Home from "./components/Home";
import './App.css';
import Course from './components/Course';
import Allcourse from "./components/Allcourses";
import AddCourse from './components/AddCourse';
import Header from './components/Header';
import Menus from './components/Menu';
import {BrowserRouter as Router, Route} from "react-router-dom"
import Allcourses from './components/Allcourses';
import  { useEffect } from 'react';
 

function App() {

  const btnhandler=()=>{
    toast("this is first msg");
  };

  useEffect(() => {
    // Update the document title using the browser API
    document.title = `Home`;
  },[]);
  
  return (

    <div><Router>
    <ToastContainer/>
    <Header/>
    <Container>
      <Row>
        <Col md={4}>
          <Menus/>
        </Col>
        <Col md={8}>
        <Route path="/" component={Home} exact/>
        <Route path="/add-course" component = {AddCourse} exact/>
        <Route path="/view-courses" component = {Allcourses} exact/>

        </Col>
      </Row>
    </Container>
    </Router>
    
    
    
    
    
    
    
    
    
     {/* <h1> Simple Application</h1>
     <Home/>
     <Allcourse/>
     <AddCourse/>
     */}
    {/* <Course 
    course={{title: "django",description: "jthis is django course"} }/>
     <Course 
    course={{title: "javA",description: "jthis is JAVA course"} }/> */} 
    </div>
  );
}

export default App;
