const base_url = "http://localhost:8080";
export default base_url;