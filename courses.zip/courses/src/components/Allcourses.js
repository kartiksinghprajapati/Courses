import base_url from "./../api/bootapi";
import axios from 'axios';
import Course from './Course';
import React, { useState, useEffect } from 'react';
import { toast } from "react-toastify";
const Allcourses=()=>{
    
    useEffect(() => {
        // Update the document title using the browser API
        document.title = `All Courses`;
       
      },[]);
   
      //function to call server
      const getAllCoursesFromServer=()=>{
          axios.get(`${base_url}/courses`).then(
              (response)=>{
                  console.log(response.data);
                  toast.success("courses has been loaded");;
                  setCourses(response.data);
              },
              (error)=>{
                console.log(error);
                toast.error("something went wrong");
            }

          );
      };
      //calling loading getAllCoursesFromServerfunction
          useEffect(() => {
           getAllCoursesFromServer();
           },[]);
   
           


    const [courses, setCourses]=useState([ ])


    return(
        <div>
            <h1>All COurses</h1>
            <p> List of Courses are as follows:</p>
        {
            courses.length>0?  courses.map((item)=>
                <Course key ={item.id} course={item}/>
            ) : "No Courses Avalable"
        }

        </div>


    )
};
export default Allcourses;