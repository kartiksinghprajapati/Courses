
import React, {useEffect} from 'react';
import {Container, Jumbotron, Button} from "reactstrap";
const Home=()=>{

    useEffect(() => {
        // Update the document title using the browser API
        document.title = `Home`;
      },[]);
      

    return(
        <div>
            <Jumbotron className= "text-center">
                <h2>Learn Code</h2>
                <p> learning react with jumbotron inside tostify 
                    and having fun makig project</p>
                    <Container>
                        <Button color="primary" outline>Start using container</Button>
                    </Container>
            </Jumbotron>

        </div>
    )
};
export default Home;