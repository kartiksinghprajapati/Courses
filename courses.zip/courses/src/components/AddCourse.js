import React, {useEffect, useState, Fragment } from 'react';
import {Form, FormGroup,Input, Button,Container } from 'reactstrap';
import axios from 'axios';
import { toast } from "react-toastify";
import base_url from "./../api/bootapi";

const AddCourse=()=>{

    useEffect(() => {
        // Update the document title using the browser API
        document.title = `AddCourse`;
      },[]);
      
      const[course, setCourses]=useState({});
      //form handler function
      const handleForm=(e)=>{
          console.log(course);
            postDataToServer(course);
          e.preventDefault();
      }

      //creating function to post data from server

      const postDataToServer=(data)=>{
            axios.post(`${base_url}/courses`, data).then(
                (response)=>{
                    console.log(response.data);
                    toast.success("successful added");;
                  
                },
                (error)=>{
                  console.log(error);
                  toast.error("error");
              }
            )
      }

    return(
        <Fragment>
            <h1 className="text-center my-3">Fill Course Details</h1>
            <Form onSubmit ={handleForm}>
                <FormGroup>
                    <label>Course Id</label>
                    <Input type ="text" placeholder="Enter here" name="userId" id ="userId" 
                    onChange ={ (e)=>{
                        setCourses({...course, id : e.target.value});
                     } } />
                </FormGroup>
                <FormGroup>
                    <label>Course Title</label>
                    <Input type ="text" placeholder="Enter title here" name="title" id ="title"
                    onChange={(e)=>{
                        setCourses({...course, title: e.target.value});
                    }}/>
                </FormGroup>
                <FormGroup>
                    <label>Course Description</label>
                    <Input type ="textarea" placeholder="Enter Description "
                     name="description" id ="description" style={{height: 100}}
                     onChange={(e)=>{
                        setCourses({...course, description: e.target.value});
                    }}/>
                </FormGroup>
                <Container className="text-center">
                    <Button  type="submit" color="success" >Add Course</Button>
                    <Button color="warning  ml-3" type="reset" >Clear</Button>
                </Container>
            </Form>
        </Fragment>
    )
};
export default AddCourse;